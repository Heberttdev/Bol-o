import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { signInWithEmailAndPassword, GoogleAuthProvider, signInWithPopup } from "firebase/auth";
import { auth } from "../services/firebase";

export default function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [mensagem, setMensagem] = useState("");

  const fazerLogin = async (e) => {
    e.preventDefault();

    try {
      await signInWithEmailAndPassword(auth, email, senha);
      navigate("/dashboard");
    } catch (error) {
      setMensagem("Email ou senha inválidos");
    }
  };

  const provider = new GoogleAuthProvider();

  async function loginGoogle() {
    try {
      const result = await signInWithPopup(auth, provider);
      console.log("LOGADO:", result.user);
      navigate("/dashboard");
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <div className="login-bg">

      <div className="login-card-bet">

        <div className="login-header">
          <h1>🏆 Bolão Chamar o Green</h1>
          <p>Entre e comece a subir no ranking</p>
        </div>

        <form onSubmit={fazerLogin} className="login-form">

          <label>Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="seu@email.com"
            required
          />

          <label>Senha</label>
          <input
            type="password"
            value={senha}
            onChange={(e) => setSenha(e.target.value)}
            placeholder="••••••••"
            required
          />

          <button type="submit" className="btn-login">
            Entrar
          </button>

        </form>

        <button onClick={loginGoogle} className="btn-google">
          <img
            src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg"
            alt="Google"
          />
          Entrar com Google
        </button>

        <div className="login-footer">
          <Link to="/cadastro">Criar conta</Link>
        </div>

        {mensagem && <p className="login-error">{mensagem}</p>}

      </div>

    </div>
  );
}