import { useAuth } from "../context/AuthContext";
import Layout from "../components/Layout";
import { useEffect, useState } from "react";
import { ref, get } from "firebase/database";
import { database } from "../services/firebase";
import { calcularPontuacao } from "../utils/calcularPontuacao";
import { Navigate } from "react-router-dom";

export default function Dashboard() {
  const { user, loading } = useAuth();

  const [dadosUsuario, setDadosUsuario] = useState(null);
  const [pontuacao, setPontuacao] = useState(0);
  const [totalPalpites, setTotalPalpites] = useState(0);
  const [posicao, setPosicao] = useState("-");
  const [topRanking, setTopRanking] = useState([]);
  const [proximosJogos, setProximosJogos] = useState([]);

  useEffect(() => {
    if (user) carregarDashboard();
  }, [user]);

  // 🔥 "ao vivo" leve (refresh automático)
  useEffect(() => {
    if (!user) return;

    const interval = setInterval(() => {
      carregarDashboard();
    }, 15000);

    return () => clearInterval(interval);
  }, [user]);

  if (loading) return <h2>Carregando...</h2>;
  if (!user) return <Navigate to="/" />;

  async function carregarDashboard() {
    try {
      const [usersSnap, betsSnap, resultadosSnap, jogosSnap] =
        await Promise.all([
          get(ref(database, "users")),
          get(ref(database, "bets")),
          get(ref(database, "resultados")),
          get(ref(database, "jogos")),
        ]);

      const jogos = Object.values(jogosSnap.val() || {});

      const futuros = jogos
        .filter((j) => new Date(j.data) >= new Date())
        .sort((a, b) => new Date(a.data) - new Date(b.data))
        .slice(0, 5);

      setProximosJogos(futuros);

      if (!usersSnap.exists() || !betsSnap.exists() || !resultadosSnap.exists())
        return;

      const usuarios = usersSnap.val();
      const apostas = betsSnap.val();
      const resultados = resultadosSnap.val();

      const listaRanking = [];

      Object.keys(usuarios).forEach((uid) => {
        let pontos = 0;

        const betsUsuario = apostas[uid] || {};

        Object.keys(betsUsuario).forEach((jogoId) => {
          pontos += calcularPontuacao(
            betsUsuario[jogoId],
            resultados[jogoId]
          );
        });

        listaRanking.push({
          uid,
          nome: usuarios[uid].nome,
          pontos,
        });

        if (uid === user.uid) {
          setDadosUsuario(usuarios[uid]);
          setPontuacao(pontos);
          setTotalPalpites(Object.keys(betsUsuario).length);
        }
      });

      listaRanking.sort((a, b) => b.pontos - a.pontos);

      setTopRanking(listaRanking.slice(0, 5));

      const indice = listaRanking.findIndex((i) => i.uid === user.uid);
      setPosicao(indice + 1);
    } catch (err) {
      console.error(err);
    }
  }

  return (
    <Layout>
      <div className="dashboard-container">

        {/* HEADER */}
        <div className="dash-header">
          <div className="user-box">
            <img
              src={user.photoURL || "/avatar.png"}
              className="avatar-glow"
              alt="perfil"
            />

            <div>
              <h2>Bem-vindo, {dadosUsuario?.nome || "Jogador"}</h2>
              <p>🔥 Bora subir nesse ranking</p>
            </div>
          </div>

          <div className="quick-actions">
            <button onClick={() => (window.location.href = "/jogos")}>
              ⚽ Jogos
            </button>

            <button onClick={() => (window.location.href = "/ranking")}>
              🏆 Ranking
            </button>
          </div>
        </div>

        {/* CARDS */}
        <div className="cards-grid">
          <div className="card glow-green">
            <h2>{pontuacao}</h2>
            <p>Pontos</p>
          </div>

          <div className="card glow-gold">
            <h2>{posicao}º</h2>
            <p>Ranking</p>
          </div>

          <div className="card glow-blue">
            <h2>{totalPalpites}</h2>
            <p>Palpites</p>
          </div>
        </div>

        {/* RANKING */}
        <div className="ranking-card">
          <h2>🏆 Top 5 Ranking</h2>

          {topRanking.map((item, index) => (
            <div
              key={item.uid}
              className={`ranking-item rank-${index + 1}`}
            >
              <span>
                {index === 0
                  ? "🥇"
                  : index === 1
                  ? "🥈"
                  : index === 2
                  ? "🥉"
                  : `#${index + 1}`}{" "}
                {item.nome}
              </span>

              <strong>{item.pontos} pts</strong>
            </div>
          ))}
        </div>

        {/* JOGOS */}
        <div className="live-card">
          <h2>📡 Próximos Jogos</h2>

          {proximosJogos.map((jogo) => (
            <div key={jogo.id} className="live-item">
              <div className="match">
                {jogo.casa} <span>VS</span> {jogo.fora}
              </div>

              <small>
                {new Date(jogo.data).toLocaleString()}
              </small>

              <div className="live-dot" />
            </div>
          ))}
        </div>

      </div>
    </Layout>
  );
}